fn main() {
    println!("Hey, Rust!");
}
