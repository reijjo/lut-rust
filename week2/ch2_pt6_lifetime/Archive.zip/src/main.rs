use ch2_pt6_lifetime::run_main;

fn main() {
    let result = run_main();
    println!("The longest string is: {}", result);
}